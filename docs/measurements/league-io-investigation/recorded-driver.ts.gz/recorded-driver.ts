import fs from 'node:fs/promises';
import { syncBuiltinESMExports } from 'node:module';
import { join, relative, resolve } from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';

// Observation only: preserve original operations, arguments, results and exceptions.
// Coordinator FileHandle reads/writes are exact API bytes; Worker I/O and streams are excluded.
const raw = { open: fs.open, readFile: fs.readFile, writeFile: fs.writeFile };
let active: any;
const root = resolve('.generated/io-investigation/data');
function local(direction: 'read' | 'write', path: unknown, bytes: number) {
  if (!active || typeof path !== 'string' || !resolve(path).startsWith(root + '/')) return;
  active.local[direction + 'Bytes'] += bytes;
  const key = relative(root, resolve(path));
  const item = active.local.files[key] ??= { reads: 0, readBytes: 0, writes: 0, writeBytes: 0 };
  item[direction + 's']++;
  item[direction + 'Bytes'] += bytes;
  if (/\/(?:objects|\.bundle-staging-[^/]+)\//.test('/' + key)) active.local['recording' + (direction === 'read' ? 'Read' : 'Write') + 'Bytes'] += bytes;
}
fs.open = async (...args: any[]) => {
  const handle = await (raw.open as any)(...args);
  const read = handle.read.bind(handle), writeFile = handle.writeFile.bind(handle);
  handle.read = async (...readArgs: any[]) => {
    const result = await read(...readArgs); local('read', args[0], result.bytesRead); return result;
  };
  handle.writeFile = async (...writeArgs: any[]) => {
    const result = await writeFile(...writeArgs);
    local('write', args[0], Buffer.byteLength(writeArgs[0])); return result;
  };
  return handle;
};
fs.readFile = async (...args: any[]) => { const result = await (raw.readFile as any)(...args); local('read', args[0], Buffer.byteLength(result)); return result; };
fs.writeFile = async (...args: any[]) => { const result = await (raw.writeFile as any)(...args); local('write', args[0], Buffer.byteLength(args[1])); return result; };
syncBuiltinESMExports();

const { BattleBundles, sha256 } = await import('@fantasy/api/artifacts');
const { leagueFixture } = await import('@fantasy/samples/testing');
const { SUPPORTED_REPLAY_FORMAT } = await import('@fantasy/domain');
const { PUBLICATION_MAX_BYTES } = await import('@fantasy/domain/spatial');
const { prepareCloudLeague, runCloudLeague, finishCloudLeague } = await import('../../apps/cli/src/league/league-cloud.ts');
const { probeLeague } = await import('../../apps/cli/src/league/league-probe.ts');
const { restorePublication } = await import('../../apps/cli/src/publication/publication-restore.ts');
const { publishPublication } = await import('../../apps/cli/src/publication/publication-remote.ts');
const { localPublicationGraph } = await import('../../apps/cli/src/publication/publication-graph.ts');
const { leagueArtifactFiles } = await import('../../apps/cli/src/league/league-artifact-files.ts');
const { preparedLeague } = await import('../../apps/cli/src/league/league-cloud-files.ts');

for (const name of ['verify','importRecorded','importConfirmed'] as const) {
  const original = BattleBundles.prototype[name];
  (BattleBundles.prototype as any)[name] = async function(...args: any[]) {
    const stage = active, start = performance.now();
    if (stage) stage.bundles[name].calls++;
    try { const result = await (original as any).apply(this,args); if (stage) stage.bundles[name].receiptBytes += result.bytes; return result; }
    finally { if(stage) stage.bundles[name].inclusiveMs += performance.now()-start; }
  };
}
class MeasuredStore {
  readonly objects = new Map<string, {data:Buffer;etag:string}>();
  version = 0;
  constructor(from?: MeasuredStore) { if(from) for(const [key,value] of from.objects) this.objects.set(key,{data:Buffer.from(value.data),etag:value.etag}); }
  remainingRequests() { return 1_000_000; }
  note(method:string,key:string,bytes=0) {
    if(!active) return;
    active.remote[method]++;
    if(method==='get') {active.remote.readBytes+=bytes; if(key.startsWith('objects/')) active.remote.recordingReadBytes+=bytes;}
    if(method==='put') {active.remote.writeBytes+=bytes; if(key.startsWith('objects/')) active.remote.recordingWriteBytes+=bytes;}
  }
  async inventory() { this.note('list',''); return new Map([...this.objects].map(([key,value])=>[key,value.data.length])); }
  async read(key:string,limit:number) { const result=this.objects.get(key)??null; if(result && result.data.length>limit) throw new Error('Observation store read limit'); this.note('get',key,result?.data.length??0); return result; }
  async head(key:string) { this.note('head',key); return this.objects.get(key)?.data.length??null; }
  async put(key:string,data:Buffer,previous:string|null) {
    const old=this.objects.get(key); if(previous===null?old!==undefined:old?.etag!==previous) throw new Error('Conditional conflict');
    this.note('put',key,data.length); this.objects.set(key,{data:Buffer.from(data),etag:`fixture-${++this.version}`});
  }
  async remove(key:string) {this.note('delete',key);this.objects.delete(key);}
  async worker(key:string,limit:number) {
    const value=this.objects.get(key); if(!value || value.data.length>limit)throw new Error('Worker fixture object missing/oversized');
    if(active){ active.worker.get++;active.worker.readBytes+=value.data.length; if(key.startsWith('objects/'))active.worker.recordingReadBytes+=value.data.length;}
    return value.data;
  }
}
const sourceSha=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const source={sha:sourceSha,node:process.versions.node,platform:process.platform,arch:process.arch} as any;
const env={sourceSha,sourceDirty:execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),node:process.version,pnpm:'11.27.1',platform:process.platform,arch:process.arch,kernel:os.release(),cpu:os.cpus()[0]?.model,logicalCpus:os.cpus().length,memoryBytes:os.totalmem(),concurrency:{publication:16,workersPerPartition:2},cache:'Fresh local restore and partition directories per case; in-memory remote store; OS page cache not flushed; no remote latency/cache emulation.'};
const report:any={schemaVersion:1,kind:'isolated-league-io-investigation',environment:env,command:'PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin:$PATH node --import ./apps/cli/node_modules/tsx/dist/loader.mjs .generated/io-investigation/measure.ts',scopeNotes:['Application source is unchanged. Existing league fixture and real pipeline functions are used.','S3 and Worker values are measured interface calls/bytes against an isolated in-memory adapter, not actual R2 requests, billing or network latency. Control leases, SDK retries and inventory pagination are excluded.','Filesystem counts cover coordinator promise/FileHandle I/O beneath the isolated fixture root, not Worker thread/SQLite/stream writes. Publication and partition inventories separately capture output bytes.','Bundle method times overlap and must not be added to stage wall time. RSS is sampled every 20 ms for the Node process (includes Workers and in-memory adapter), not a verified per-stage high-water mark.','One repetition per scenario; timing is observation, not performance acceptance. 1 partition in measured scenarios; no cross-partition scaling claim.'],cases:[]};
let caseRecord:any;
async function measure(name:string,fn:()=>Promise<any>,expectedFailure=false) {
  const metric:any={phase:name,wallMs:0,local:{readBytes:0,writeBytes:0,recordingReadBytes:0,recordingWriteBytes:0,files:{}},remote:{get:0,head:0,list:0,put:0,delete:0,readBytes:0,writeBytes:0,recordingReadBytes:0,recordingWriteBytes:0},worker:{get:0,readBytes:0,recordingReadBytes:0},bundles:Object.fromEntries(['verify','importRecorded','importConfirmed'].map(key=>[key,{calls:0,receiptBytes:0,inclusiveMs:0}])),rssSampledPeakBytes:process.memoryUsage.rss()};
  caseRecord.stages.push(metric); active=metric;const start=performance.now();
  const timer=setInterval(()=>{metric.rssSampledPeakBytes=Math.max(metric.rssSampledPeakBytes,process.memoryUsage.rss());},20);
  let result;
  try{result=await fn();metric.status='passed';if(expectedFailure)throw new Error('Expected rejection was not observed');}
  catch(error){metric.status='rejected';metric.error=error instanceof Error?error.message:'unknown';if(!expectedFailure)throw error;}
  finally{clearInterval(timer);metric.wallMs=Math.round((performance.now()-start)*100)/100;metric.rssSampledPeakBytes=Math.max(metric.rssSampledPeakBytes,process.memoryUsage.rss());active=undefined; for(const m of Object.values(metric.bundles) as any[])m.inclusiveMs=Math.round(m.inclusiveMs*100)/100;}
  metric.result=result; console.log(JSON.stringify({case:caseRecord.name,phase:name,wallMs:metric.wallMs,status:metric.status,remote:metric.remote,bundleVerifications:metric.bundles.verify.calls}));
  return result;
}
const options=(store:MeasuredStore)=>({viewer:async()=>({schemaVersion:1,sourceSha,publicationSchema:1,replay:SUPPORTED_REPLAY_FORMAT}),ancestor:(a:string,b:string)=>a===sourceSha&&b===sourceSha,worker:(key:string,limit:number)=>store.worker(key,limit),maxTransferBytes:PUBLICATION_MAX_BYTES,maxWrites:100000,maxWorkerRequests:1000,concurrency:16});
const inventory=(store:MeasuredStore)=>({files:store.objects.size,bytes:[...store.objects.values()].reduce((n,x)=>n+x.data.length,0),receipts:[...store.objects.keys()].filter(k=>k.endsWith('/receipt.json')).length,usedReadRequests:10000,usedWriteRequests:10000});
async function stagePublish(name:string,path:string,store:MeasuredStore) {
  // transferCloudLeague calls a full local graph for its lease estimate, then publishPublication calls it again.
  await measure(name+'-lease-graph',async()=>{const graph=await localPublicationGraph(path);return {files:graph.files.size,bytes:graph.totalBytes,objects:graph.objects.size};});
  return measure(name,()=>publishPublication(path,store,options(store)));
}
async function finishSetup(name:string,definition:any,store:MeasuredStore,base?:MeasuredStore,missing=false) {
  const path=join(root,name); await fs.mkdir(path,{recursive:true});
  const pub=join(path,'public'),prep=join(path,'prepared');
  if(base) await measure('restore',()=>restorePublication(pub,store,PUBLICATION_MAX_BYTES,16));
  const plan=await measure('prepare',()=>prepareCloudLeague(definition,source,name,pub,prep,inventory(store)));
  await stagePublish('admit',pub,store);
  if(!missing) for(let i=0;i<plan.prepared.inputs.length;i++) await measure('run-'+i,()=>runCloudLeague(join(prep,'inputs',String(i)),join(path,'results',String(i)),source,name));
  await measure('finish',()=>finishCloudLeague(prep,join(path,'results'),pub,source,name));
  await stagePublish('publish',pub,store);
  return {path,pub,prep};
}
async function caseStart(name:string,description:string){caseRecord={name,description,stages:[]};report.cases.push(caseRecord);}
await fs.mkdir(root,{recursive:false});
const small=await leagueFixture(3,1), large=await leagueFixture(4,1);
report.inputs={small:{characters:3,battlefields:1,trials:2,placements:2,planned:12},large:{characters:4,battlefields:1,trials:2,placements:2,planned:24},masterSeed:42,ruleset:small.ruleset};
await caseStart('setup-complete-baseline','12 real, small fixture battles; setup is recorded separately from comparisons');
const baseline=new MeasuredStore();
const baselinePaths=await finishSetup('baseline',small,baseline);
report.baseline={...inventory(baseline),recordingBytes:[...baseline.objects].filter(([k])=>k.startsWith('objects/')).reduce((n,[,v])=>n+v.data.length,0),recordingFiles:[...baseline.objects.keys()].filter(k=>k.startsWith('objects/')).length};
await caseStart('unchanged','Same definitions/input, complete retained outcomes');
const unchanged=await measure('probe',()=>probeLeague(small,sourceSha,(k,l)=>baseline.worker(k,l)));assert.equal(unchanged.needed,false);assert.equal(unchanged.estimate.compute,0);caseRecord.skipped=['restore','prepare','admit','compute','finish','publish'];
async function updated(name:string,store:MeasuredStore,expect:any){
 await caseStart(name,expect.description);
 const probe=await measure('probe',()=>probeLeague(large,sourceSha,(k,l)=>store.worker(k,l)));assert.equal(probe.needed,true); for(const [k,v]of Object.entries(expect.estimate))assert.equal(probe.estimate[k],v);
 const path=join(root,name);await fs.mkdir(path);const pub=join(path,'public'),prep=join(path,'prepared');
 await measure('restore',()=>restorePublication(pub,store,PUBLICATION_MAX_BYTES,16));
 const plan=await measure('prepare',()=>prepareCloudLeague(large,source,name,pub,prep,inventory(store)));
 await stagePublish('admit',pub,store);
 // Artifact selection is measured without fabricating control reports or contacting GitHub.
 const baselineGraph=await measure('baseline-artifact-validation',async()=>{const graph=await localPublicationGraph(pub);return {files:graph.files.size,bytes:graph.totalBytes,objects:graph.objects.size};});
 const artifact:any={baselinePublic:baselineGraph,input:[],result:[]};
 for(let i=0;i<plan.prepared.inputs.length;i++) artifact.input.push(await measure('input-artifact-'+i,async()=>{const a=await leagueArtifactFiles(join(prep,'inputs',String(i)),'input');return {files:a.files.length,bytes:a.bytes};}));
 for(let i=0;i<plan.prepared.inputs.length;i++) {
   await measure('run-'+i,()=>runCloudLeague(join(prep,'inputs',String(i)),join(path,'results',String(i)),source,name));
   artifact.result.push(await measure('result-artifact-'+i,async()=>{const a=await leagueArtifactFiles(join(path,'results',String(i)),'result');return {files:a.files.length,bytes:a.bytes};}));
 }
 await measure('finish',()=>finishCloudLeague(prep,join(path,'results'),pub,source,name));
 await stagePublish('publish',pub,store);caseRecord.artifacts=artifact;
 const after=await probeLeague(large,sourceSha,(k,l)=>store.worker(k,l));assert.equal(after.needed,false);assert.equal(after.estimate.reused,24);
}
await updated('add-character',new MeasuredStore(baseline),{description:'3 to 4 characters: 12 reused slots, 12 new slots',estimate:{planned:24,reused:12,newMatches:12,retries:0}});
await caseStart('setup-partial-baseline','12 complete retained slots plus 12 reserved attempts whose Worker never returned');
const partial=new MeasuredStore(baseline);
await finishSetup('partial-baseline',large,partial,baseline,true);
await updated('retry-partial',new MeasuredStore(partial),{description:'Retry only 12 missing slots of 24; retain 12 complete outcomes',estimate:{planned:24,reused:12,newMatches:0,retries:12}});
const corruptionKey=[...baseline.objects.keys()].find(k=>k.startsWith('objects/')&&k.endsWith('.gz'))!;assert.ok(corruptionKey);
for(const fault of ['missing','corrupt'] as const){
 await caseStart('recording-'+fault,'Corruption exists only in cloned isolated adapter; restore must reject before prepare or publication');
 const broken=new MeasuredStore(baseline),before=broken.objects.get('catalog/current.json')!.data;
 if(fault==='missing')broken.objects.delete(corruptionKey);else{const v=broken.objects.get(corruptionKey)!;const data=Buffer.from(v.data);data[0]^=0xff;broken.objects.set(corruptionKey,{...v,data});}
 const probe=await measure('unchanged-probe',()=>probeLeague(small,sourceSha,(k,l)=>broken.worker(k,l)));assert.equal(probe.needed,false);
 const changed=await measure('changed-probe',()=>probeLeague(large,sourceSha,(k,l)=>broken.worker(k,l)));assert.equal(changed.needed,true);
 const failedPath=join(root,'recording-'+fault,'public');await measure('restore',()=>restorePublication(failedPath,broken,PUBLICATION_MAX_BYTES,16),true);
 assert.equal(await fs.stat(failedPath).then(()=>true,()=>false),false);assert.deepEqual(broken.objects.get('catalog/current.json')!.data,before);
 caseRecord.rejectedBefore=['prepare','admit','compute','finish','publish'];caseRecord.cleanedPartialRestore=true;caseRecord.remotePointerUnchanged=true;
}
report.completedAt=new Date().toISOString();report.processMaxRssKb=process.resourceUsage().maxRSS;
await raw.writeFile('.generated/io-investigation/results.json',JSON.stringify(report,null,2)+'\n');
console.log('Saved .generated/io-investigation/results.json');
